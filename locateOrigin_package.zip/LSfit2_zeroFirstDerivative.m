% ______________________________________________________________________________
% 
%  Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>
% 
%  All rights reserved.
% 
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
% 
%    a. Redistributions of source code must retain the above copyright notice,
%       this list of conditions and the following disclaimer.
% 
%    b. Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in the
%       documentation and/or other materials provided with the distribution.
% 
%    c. Neither the name of the copyright holders nor the names of any
%       contributors to this software may be used to endorse or promote products
%       derived from this software without specific prior written permission.
% 
% 
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
%  "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
%  REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
%  NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
%  DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
%  ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
%  ANY THIRD PARTY RIGHTS.
% 
%  THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
%  ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
%  CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
%  OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
%  OF THE POSSIBILITY THEREOF.
% ______________________________________________________________________________





function p = LSfit2_zeroFirstDerivative(x,y)

% Computes the coefficients of the 2nd order polynomial
%       p(1)x^2 + p(3)
% that fits the data (x,y) in the least squares sense, enforcing a zero
% first derivative at x=0.
%
% INPUT:
%  x = vector of independent variables.
%  y = vector of data, y = y(x).
%
% OUTPUT:
%  p = coefficients of 2nd order polynomial fit.  In particular, p(3) is
%      the intercept.
%
%
% Written by Daniel N. Kaslovsky, kaslovsky@colorado.edu


N = length(x);

% Ensure data are given as column vectors.
x = x(:);
y = y(:);

% Define orthogonal polynomials.
Rmax = x(N);
Rmin = x(1);
VV(:,2) = ones(N,1);
VV(:,1) = x - ((Rmax+Rmin)/2);

% Solve the least squares problem.
[Q,R] = qr(VV,0);
pp = R\(Q'*y);

% Enforce that the linear coefficient is zero at x=0.
p = [pp(1)/(Rmax+Rmin), ...
     0, ...
     pp(2)-(1/3)*(pp(1)/(Rmax+Rmin))*(Rmax^2+Rmax*Rmin+Rmin^2)];
 
 return;