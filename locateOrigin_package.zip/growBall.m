% ______________________________________________________________________________
% 
%  Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>
% 
%  All rights reserved.
% 
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
% 
%    a. Redistributions of source code must retain the above copyright notice,
%       this list of conditions and the following disclaimer.
% 
%    b. Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in the
%       documentation and/or other materials provided with the distribution.
% 
%    c. Neither the name of the copyright holders nor the names of any
%       contributors to this software may be used to endorse or promote products
%       derived from this software without specific prior written permission.
% 
% 
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
%  "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
%  REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
%  NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
%  DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
%  ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
%  ANY THIRD PARTY RIGHTS.
% 
%  THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
%  ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
%  CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
%  OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
%  OF THE POSSIBILITY THEREOF.
% ______________________________________________________________________________





function [Xsorted,radii,idx] = growBall(X,ctr,dim)

% Grow a ball in R^dim centered about the point ctr and return the sample
% points in X sorted by Euclidean distance (radius) from ctr, the radius
% corresponding to each point, and the sorting index.
%
% INPUT:
%  X   = D x N data matrix.
%  ctr = D x 1 vector containing the point about which to center the ball.
%  dim = dimension of the ball.  Default = size(X,1).
%
% OUTPUT:
%  Xsorted = D x N data matrix sorted according to the distance (radius) of
%            each point (column) from ctr.
%  radii   = vector containing the radius corresponding to each point
%            in Xsorted.
%  idx     = vector of indices such that Xsorted = X(:,idx).
%
%
% Written by Daniel N. Kaslovsky, kaslovsky@colorado.edu


if (nargin < 3)
    dim = size(X,1);
end

radii = sqrt(sum((X(1:dim,:) - repmat(ctr(1:dim),1,size(X,2))).^2,1));
[radii,idx] = sort(radii,'ascend');      
Xsorted = X(:,idx);

return;