% ______________________________________________________________________________
% 
%  Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>
% 
%  All rights reserved.
% 
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
% 
%    a. Redistributions of source code must retain the above copyright notice,
%       this list of conditions and the following disclaimer.
% 
%    b. Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in the
%       documentation and/or other materials provided with the distribution.
% 
%    c. Neither the name of the copyright holders nor the names of any
%       contributors to this software may be used to endorse or promote products
%       derived from this software without specific prior written permission.
% 
% 
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
%  "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
%  REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
%  NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
%  DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
%  ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
%  ANY THIRD PARTY RIGHTS.
% 
%  THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
%  ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
%  CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
%  OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
%  OF THE POSSIBILITY THEREOF.
% ______________________________________________________________________________





function origin_est = locateOrigin(X,refpt)

% Estimate the origin of the local manifold neighborhood by finding the
% point on the manifold closest to refpt.
%
% INPUT:
%  X          = D x N matrix containing the data set
%  refpt      = D x 1 vector containing the starting point for which we
%               seek the closest point on the manifold (the origin of the
%               local manifold neighborhood).
%
% OUTPUT:
%  origin_est = D x 1 vector containing the estimate of the origin.
%
%
% Written by Daniel N. Kaslovsky, kaslovsky@colorado.edu


N = size(X,2);

% Set the scale intervals to be used.
% The interval for iteration j is stored in scales(j,:).
scales = round([ [.5 .75]*N; ...
                 [1 .4*N];   ...
                 [1 .3*N];   ...
                 [1 .25*N]; ]);

nScales = size(scales,1);

% Start at rept and recompute the origin at each scale interval.
origin_est = refpt;

for scl = 1:nScales
    origin_est = getNewPt(X,origin_est,scales(scl,:),scales(scl,2));
end


return;