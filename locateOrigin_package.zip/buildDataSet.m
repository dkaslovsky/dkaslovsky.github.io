% ______________________________________________________________________________
% 
%  Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>
% 
%  All rights reserved.
% 
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
% 
%    a. Redistributions of source code must retain the above copyright notice,
%       this list of conditions and the following disclaimer.
% 
%    b. Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in the
%       documentation and/or other materials provided with the distribution.
% 
%    c. Neither the name of the copyright holders nor the names of any
%       contributors to this software may be used to endorse or promote products
%       derived from this software without specific prior written permission.
% 
% 
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
%  "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
%  REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
%  NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
%  DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
%  ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
%  ANY THIRD PARTY RIGHTS.
% 
%  THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
%  ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
%  CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
%  OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
%  OF THE POSSIBILITY THEREOF.
% ______________________________________________________________________________





function [X,refpt,Xclean] = buildDataSet(d,D,N,kappas,sigma,origin,rot)

% Construct a data set according to the quadratic manifold neighborhood
% model.
%
% INPUT:
%  d      = intrinsic dimension (dimension of the manifold).
%  D      = dimension of the ambient space.
%  N      = number of points to be used in the local manifold neighborhood.
%  kappas = (D-d) x d matrix of principal curvatures such that kappas(i,j)
%           contains the jth principal curvature in normal direction i.
%  sigma  = standard deviation of the Gaussian noise (the "noise-level").
%  origin = D x 1 vector containing the coordinates of the local origin.
%           Default is [0 0 ... 0]'.
%  rot    = D x D (unitary) rotation matrix to be applied to the data set.
%           Default is the identity matrix I_D.
%
% OUTPUT:
%  X      = D x N matrix containing the data set with the data points
%           stored in the columns.
%  refpt  = randomly generated D x 1 vector containing the initial point
%           for which we seek the closest point on the manifold (the local
%           origin).
%  Xclean = D x N matrix containing the noise-free data set.
%
%
% Written by Daniel N. Kaslovsky, kaslovsky@colorado.edu


% Set defaults
if (nargin < 6)
    origin = zeros(D,1);
    rot = eye(D);
end

if (nargin < 7)
    rot = eye(D);
end


% Uniformly sample the d-dimensional ball.
% These will be the sample points from the tangent plane.
rmax = 1;
x = zeros(d,N);
for i = 1:N
    x(:,i) = randn(d,1);            % normal distribution
    u = rand;                       % uniform distribution
    x(:,i) = rmax*(u^(1/d))*(x(:,i)/norm(x(:,i)));
end


% Build the local manifold neighborhood according to the quadratic model.
% Coordinate j, (d+1) < j < D, has the form
%      f_j(x) = (1/2)*(\kappa^(j)_1*x_1^2 + ... + \kappa^(j)_d*x_d^2).
y = zeros(D-d,N);
for j = 1:D-d
    for i = 1:d
        y(j,:) = y(j,:) + kappas(j,i)*x(i,:).^2;
    end
    y(j,:) = .5*y(j,:);
end

Xclean = [x;y];
clear x y;


% Apply the rotation
Xclean = rot*Xclean;

% Shift the origin
Xclean = Xclean + origin*ones(1,N);

% Add noise
E = sigma*randn(D,N);      
X = Xclean + E;


% Generate reference point at which the iteration is started (i.e., the
% noisy point for which we seek the closest point on the manifold).
sigma_refpt = 2*sigma;
refpt = origin + rot*[zeros(d,1);sigma_refpt*randn(D-d,1)];

return;