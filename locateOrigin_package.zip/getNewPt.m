% ______________________________________________________________________________
% 
%  Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>
% 
%  All rights reserved.
% 
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
% 
%    a. Redistributions of source code must retain the above copyright notice,
%       this list of conditions and the following disclaimer.
% 
%    b. Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in the
%       documentation and/or other materials provided with the distribution.
% 
%    c. Neither the name of the copyright holders nor the names of any
%       contributors to this software may be used to endorse or promote products
%       derived from this software without specific prior written permission.
% 
% 
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
%  "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
%  REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
%  NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
%  DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
%  ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
%  ANY THIRD PARTY RIGHTS.
% 
%  THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
%  ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
%  CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
%  OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
%  OF THE POSSIBILITY THEREOF.
% ______________________________________________________________________________





function [new_pt,p] = getNewPt(X,refpt,interval,Nmax)

% Uses the least squares fit of the center trajectory to update each
% coordinate.
%
% INPUT:
%  X        = D x N matrix containing the data set
%  refpt    = D x 1 vector containing the reference point about which to
%             center the ball.
%  interval = vector indicating the interval of radii over which the least
%             squares fit is computed: interval(1) = beginning of the
%             interval, interval(2) = end of the interval.
%  Nmax     = number of points to be used (optional, Default = N).
%
% OUTPUT:
%  new_pt   = D x 1 vector containig updated coordinates.
%  p        = coefficients of the least squares fit.
%
%
% Written by Daniel N. Kaslovsky, kaslovsky@colorado.edu


[D,N] = size(X);

% Set defaults.
if ( (nargin < 3) || (Nmax > N) )
    Nmax = N;
end

% Get center trajectory and radii R about refpt.
[ctrTraj,R] = getCenterTrajectory(X,refpt,Nmax);

% Initialize variables.
strt = interval(1);
fnsh = interval(2);
n = 2;                    % fit to a n-th order polynomial
p = zeros(D,n+1);         % jth row holds the coefficients for coodinate j
new_pt = zeros(D,1);


% Update each coordinate.
for coord = 1:D
    
    % Get least squares coefficients for trajectory of current coordinate.
    p(coord,:) = LSfit2_zeroFirstDerivative( R(strt:fnsh), ...
                                             ctrTraj(coord,strt:fnsh) );

    % Intercept is used as the new coordinate.
    new_pt(coord) = p(coord,n+1);
    
end


return;