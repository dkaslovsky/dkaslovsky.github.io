______________________________________________________________________________

 Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>

 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

   a. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.

   b. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   c. Neither the name of the copyright holders nor the names of any
      contributors to this software may be used to endorse or promote products
      derived from this software without specific prior written permission.


 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
 "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
 REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
 NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
 DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
 ANY THIRD PARTY RIGHTS.

 THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
 ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
 CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
 OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
 OF THE POSSIBILITY THEREOF.
______________________________________________________________________________



This code implements Algorithm 1 described in "Non-Asymptotic Analysis of Tangent Space
Perturbation", D.N. Kaslovsky and F.G. Meyer, http://arxiv.org/abs/1111.4601.

To use the code, first generate a data set according to the local manifold neighborhood model:

>> [X,y] = buildDataSet(d,D,N,kappas,sigma,origin,rot);

To build the data set, you will need to specify:
-d, the intrinsic dimension of the manifold
-D, the dimension of the ambient space
-N, the number of points to be used
-kappas, the (D-d) x d matrix of principal curvatures such that kappas(i,j) contains the jth principal curvature in normal direction i.
-sigma, the standard deviation of the Gaussian noise.
-origin, a D x 1 vector containing the coordinates of the local origin (optional, default is [0 0 ... 0]').
-rot, a D x D (unitary) rotation matrix to be applied to the data (optional, default is the identity matrix I_D).

The data is stored as columns of the D x N matrix X.  An initial point y, for which we seek the closest point on the manifold, is randomly generated.  By construction, the closest point on the manifold is the origin specified above.  You may generate your own initial point y, but this point must have the same first d coordinates as the origin before the rotation is applied.

Next, an estimate of the clean local origin is found:

>> origin_estimate = locateOrigin(X,y);

Note that the scale intervals used for Algorithm 1 are hard-coded in locateOrigin.m.  You may modify the intervals by changing the matrix called scales.

Please report any bugs or send feedback to:

Daniel Kaslovsky
kaslovsky@colorado.edu
http://www.danielkaslovsky.com