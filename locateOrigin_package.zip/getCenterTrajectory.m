% ______________________________________________________________________________
% 
%  Copyright (C) 2013 Daniel N. Kaslovsky <kaslovsky@colorado.edu>
% 
%  All rights reserved.
% 
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions are met:
% 
%    a. Redistributions of source code must retain the above copyright notice,
%       this list of conditions and the following disclaimer.
% 
%    b. Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in the
%       documentation and/or other materials provided with the distribution.
% 
%    c. Neither the name of the copyright holders nor the names of any
%       contributors to this software may be used to endorse or promote products
%       derived from this software without specific prior written permission.
% 
% 
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ON AN
%  "AS IS" BASIS. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
%  REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
%  NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
%  DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
%  ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
%  ANY THIRD PARTY RIGHTS.
% 
%  THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
%  ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
%  CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
%  OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
%  OF THE POSSIBILITY THEREOF.
% ______________________________________________________________________________





function [ctr,R,Xs] = getCenterTrajectory(X,refpt,Nmax)

% Compute the center of mass of the points in a ball of increasing radius
% centered about refpt.
%
% INPUT:
%  X     = D x N matrix containing the data set.
%  refpt = D x 1 vector containing the reference point about which to
%          center the ball.
%  Nmax  = number of points to be used (optional, Default = N).
%
% OUTPUT:
%  ctr   = D x Nmax matrix such that column j contains the coordinates of
%          the center of mass of the first j points inside the ball.
%  R     = vector containing the radius at which each point is found.
%  Xs    = D x N matrix containing the data set sorted according to radius.
%
%
% Written by Daniel N. Kaslovsky, kaslovsky@colorado.edu


[D,N] = size(X);

% Set defaults.
if ( (nargin < 3) || (Nmax > N) )
    Nmax = N;
end


% Grow a ball in R^D centered about refpt (sort X by distance from refpt
% and store the distances as radii).
[Xs,R] = growBall(X,refpt,D);

% Get the coordinates of the center of mass as the ball grows.
ctr = zeros(D,Nmax);
runningSum = 0;
for i = 1:Nmax
    runningSum = runningSum + Xs(:,i);
    ctr(:,i) = runningSum/i;
end

% Return only Nmax radii.
R = R(1:Nmax);


return;